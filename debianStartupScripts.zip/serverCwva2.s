#!/bin/sh
#
cd /home/rick_spates/cwva
#
mv err.log log/err_$(date -d "today" +"%Y%m%d%H%M").log
mv out.log log/out_$(date -d "today" +"%Y%m%d%H%M").log
#
export PATH=$PATH:~/bin
#
# Find the latest jar file by version number
LATEST_JAR=$(ls ~/cwvaServer/target/cwvaServer-*.jar 2>/dev/null | sort -V | tail -1)
#
if [ -z "$LATEST_JAR" ]; then
    echo "Error: No cwvaServer jar found in ~/cwvaServer/target/" >&2
    exit 1
fi
#
sudo java -cp res:$LATEST_JAR -Dgcp_bucket=$gcp_bucket -Dfile.encoding=UTF-8 cwva.Main -cfg res/serverCwva2.rson >out.log 2>err.log &

