#!/bin/sh
#
cd /home/rick_spates/cwva
#
mv ferr.log log/ferr_$(date -d "today" +"%Y%m%d%H%M").log
mv fout.log log/fout_$(date -d "today" +"%Y%m%d%H%M").log
#
export PATH=$PATH:~/bin
#
# Find the latest jar file by version number
LATEST_JAR=$(ls ~/cwvaServer/target/cwvaServer-*.jar 2>/dev/null | sort -V | tail -1)
#
if [ -z "$LATEST_JAR" ]; then
    echo "Error: No cwvaServer jar found in ~/cwvaServer/target/" >&2
    exit 1
fi
#
sudo java -cp res:$LATEST_JAR -Dgcp_bucket=$gcp_bucket -Dfile.encoding=UTF-8 -Xmx256m function.Main -cfg res/serverFcn.rson >fout.log 2>ferr.log &

