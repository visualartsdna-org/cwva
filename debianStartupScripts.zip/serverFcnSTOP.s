#!/bin/sh
#
#
wget http://34.72.230.88:8081/cestfini

