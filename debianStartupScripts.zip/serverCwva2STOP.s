#!/bin/sh
#
#
wget https://www.visualartsdna.org/cestfini

